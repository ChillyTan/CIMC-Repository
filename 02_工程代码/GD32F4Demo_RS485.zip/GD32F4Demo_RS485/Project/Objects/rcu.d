.\objects\rcu.o: ..\HW\RCU\RCU.c
.\objects\rcu.o: ..\HW\RCU\RCU.h
.\objects\rcu.o: ..\ARM\System\gd32f470x_conf.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_rcu.h
.\objects\rcu.o: ..\ARM\System\gd32f4xx.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm4.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\rcu.o: ..\ARM\System\system_gd32f4xx.h
.\objects\rcu.o: ..\ARM\System\gd32f4xx_libopt.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_rcu.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_adc.h
.\objects\rcu.o: ..\ARM\System\gd32f4xx.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_can.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_crc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_ctc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_dac.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_dbg.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_dci.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_dma.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_exti.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_fmc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_fwdgt.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_gpio.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_syscfg.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_i2c.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_iref.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_pmu.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_rtc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_sdio.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_spi.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_timer.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_trng.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_usart.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_wwdgt.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_misc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_enet.h
.\objects\rcu.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdlib.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_exmc.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_ipa.h
.\objects\rcu.o: ..\FW\Include\gd32f4xx_tli.h
