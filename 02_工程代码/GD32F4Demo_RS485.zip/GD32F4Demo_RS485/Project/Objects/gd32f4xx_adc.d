.\objects\gd32f4xx_adc.o: ..\FW\Source\gd32f4xx_adc.c
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_adc.h
.\objects\gd32f4xx_adc.o: ..\ARM\System\gd32f4xx.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm4.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\gd32f4xx_adc.o: ..\ARM\System\system_gd32f4xx.h
.\objects\gd32f4xx_adc.o: ..\ARM\System\gd32f4xx_libopt.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_rcu.h
.\objects\gd32f4xx_adc.o: ..\ARM\System\gd32f4xx.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_adc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_can.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_crc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_ctc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_dac.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_dbg.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_dci.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_dma.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_exti.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_fmc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_fwdgt.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_gpio.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_syscfg.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_i2c.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_iref.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_pmu.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_rtc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_sdio.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_spi.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_timer.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_trng.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_usart.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_wwdgt.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_misc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_enet.h
.\objects\gd32f4xx_adc.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdlib.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_exmc.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_ipa.h
.\objects\gd32f4xx_adc.o: ..\FW\Include\gd32f4xx_tli.h
