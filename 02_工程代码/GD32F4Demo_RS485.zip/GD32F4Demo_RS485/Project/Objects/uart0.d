.\objects\uart0.o: ..\HW\UART0\UART0.c
.\objects\uart0.o: ..\HW\UART0\UART0.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\uart0.o: ..\ARM\System\gd32f470x_conf.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_rcu.h
.\objects\uart0.o: ..\ARM\System\gd32f4xx.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm4.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\uart0.o: ..\ARM\System\system_gd32f4xx.h
.\objects\uart0.o: ..\ARM\System\gd32f4xx_libopt.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_rcu.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_adc.h
.\objects\uart0.o: ..\ARM\System\gd32f4xx.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_can.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_crc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_ctc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_dac.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_dbg.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_dci.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_dma.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_exti.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_fmc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_fwdgt.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_gpio.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_syscfg.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_i2c.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_iref.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_pmu.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_rtc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_sdio.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_spi.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_timer.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_trng.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_usart.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_wwdgt.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_misc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_enet.h
.\objects\uart0.o: D:\Program Files (x86)\ARM\ARMCC\Bin\..\include\stdlib.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_exmc.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_ipa.h
.\objects\uart0.o: ..\FW\Include\gd32f4xx_tli.h
.\objects\uart0.o: ..\HW\UART0\Queue.h
