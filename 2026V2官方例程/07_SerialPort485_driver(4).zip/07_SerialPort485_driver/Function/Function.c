/************************************************************
 * ��Ȩ��2025CIMC Copyright��
 * �ļ���Function.c
 * ����: Jialei Zhao
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Jialei Zhao     2025/12/31     V0.01    original
************************************************************/


/************************* ͷ�ļ� *************************/

#include "Function.h"
#include "usart.h"
#include "usart0.h"
#include "LED.h"	

/************************* �궨�� *************************/


/************************ �������� ************************/



/************************ �������� ************************/


/************************************************************
 * Function :       System_Init
 * Comment  :       ���ڳ�ʼ��MCU
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/

void System_Init(void)
{
	systick_config();     // ʱ������

	LED_Init();

	usart_init();

}

/************************************************************
 * Function :       UsrFunction
 * Comment  :       �û�������: LED1��˸
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/


void UsrFunction(void)
{


	while (1)
	{

		usart_recv_buf();

		usart_send_str("485_send_OK\r\n", 14);

		delay_1ms(1000);
	}
}


/****************************End*****************************/

