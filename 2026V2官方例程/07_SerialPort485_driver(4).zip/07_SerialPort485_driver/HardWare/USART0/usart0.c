/************************************************************
 * ��Ȩ��2025CIMC Copyright��
 * �ļ���usart.c
 * ����: Jialei Zhao
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Jialei Zhao     2025/12/29     V0.01    original
************************************************************/

/************************* ͷ�ļ� *************************/
#include "usart.h"
#include "stdio.h"

/************************* �궨�� *************************/

/************************ �������� ************************/

uint8_t usart0_recv_buf[128] = { 0 };
uint8_t usart0_recv_len = 0;

uint8_t usart0_real_recv_buf[128] = { 0 };
uint8_t usart0_real_recv_len = 0;

uint8_t usart0_recv_flag = 0;

/************************************************************
 * Function :       my_usart_init
 * Comment  :       ���ڳ�ʼ��MCU��USART0 ֻ���������
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2025-12-29 V0.01 original
************************************************************/

void my_usart_init(void) {

    //! ���ȿ�����Ӧ���жϴ�������     <------------------------------
    nvic_irq_enable(USART0_IRQn, 3, 3);

    //! ʹ��USARTʱ��
    rcu_periph_clock_enable(RCU_USART0);
    rcu_periph_clock_enable(RCU_GPIOA);

    // ��TX���ó�Ϊ����ģʽ
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_9);

    // ����GPIO����ģʽ
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_9);
    // ����GPIO���Ų���
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);

    // ��RX���ó�Ϊ����ģʽ
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_10);

    // ����GPIO����ģʽ
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_10);
    // ����GPIO���Ų���
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_10);

    // ����USART
    usart_deinit(USART0);
    usart_baudrate_set(USART0, 115200U);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);


    usart_interrupt_enable(USART0, USART_INT_RBNE);
    usart_interrupt_enable(USART0, USART_INT_IDLE);

    usart_enable(USART0);

}

/************************************************************
 * Function :       fputc
 * Comment  :       �û�������: ʵ��USART0���ַ����
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2025-12-29 V0.01 original
************************************************************/
int fputc(int ch, FILE* f)
{
    usart_data_transmit(USART0, (uint8_t)ch);

    while (usart_flag_get(USART0, USART_FLAG_TBE) == RESET)
    {
        ;
    }
    return ch;
}

/************************************************************
 * Function :       USART0_IRQHandler
 * Comment  :       �������ַ�����USART0���жϴ�������
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2025-12-30 V0.1 original
************************************************************/
void USART0_IRQHandler(void)
{
    // usart0_recv_flag = 1;
    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_RBNE) != RESET)
    {
        if (usart0_recv_len < sizeof(usart0_recv_buf)) {
            usart0_recv_buf[usart0_recv_len++] = usart_data_receive(USART0);
        }
    }
    //! ���в��������ݵĽ���
    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_IDLE) != RESET && usart0_recv_len != 0)
    {
        memcpy(usart0_real_recv_buf, usart0_recv_buf, usart0_recv_len);
        usart0_real_recv_len = usart0_recv_len;
        usart0_recv_len = 0;
        usart0_recv_flag = 1;
        //������λ
        usart_data_receive(USART0);
    }
}

/****************************End*****************************/


