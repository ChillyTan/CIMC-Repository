/************************************************************
 * ��Ȩ��2025CIMC Copyright��
 * �ļ���usart.h
 * ����: Jialei Zhao
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Jialei Zhao     2025/12/30     V0.01    original
************************************************************/

#ifndef __USART_H__
#define __USART_H__

/************************* ͷ�ļ� *************************/
#include "HeaderFiles.h"

/************************* �궨�� *************************/
#define USART_PORT GPIOD
#define USART USART1
#define USART_TX_Pin GPIO_PIN_5
#define USART_RX_Pin GPIO_PIN_6
#define USARTX_RCU RCU_USART1
#define USART_PIN_RCU RCU_GPIOD


#define USART_485_CS_RCU RCU_GPIOE
#define USART_485_CS_PORT GPIOE
#define USARTX_485_CS_Pin GPIO_PIN_8

#define USARTX_485_Send 1
#define USARTX_485_Receive 0



/************************ �������� ************************/


/************************ �������� ************************/

void usart_init(void);
void usart_send_str(uint8_t* str, uint8_t len);
void usart_recv_buf(void);

#endif // !__USART_H__
/****************************End*****************************/
