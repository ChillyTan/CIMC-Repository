/************************************************************
 * ��Ȩ��2025CIMC Copyright�� 
 * �ļ���USART.h
 * ����: Qiao Qin @ GigaDevice
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Qiao Qin     2025/4/20     V0.01    original
************************************************************/
#ifndef __USART_H
#define __USART_H
#include "HeaderFiles.h"

void gd_eval_com_init(void);

#endif

