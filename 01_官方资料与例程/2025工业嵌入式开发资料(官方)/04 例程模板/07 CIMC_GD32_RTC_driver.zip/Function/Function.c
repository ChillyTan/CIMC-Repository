/************************************************************
 * ��Ȩ��2025CIMC Copyright�� 
 * �ļ���Function.c
 * ����: Lingyu Meng
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Lingyu Meng     2025/2/16     V0.01    original
************************************************************/


/************************* ͷ�ļ� *************************/

#include "Function.h"
#include "LED.h"
#include "RTC.h"
#include "USART.h"

/************************* �궨�� *************************/


/************************ �������� ************************/


/************************ �������� ************************/



/************************************************************ 
 * Function :       System_Init
 * Comment  :       ���ڳ�ʼ��MCU
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/

void System_Init(void)
{
	systick_config();     // ʱ������
	
	gd_eval_com_init();   // ���ڳ�ʼ��
	
	LED_Init();			  // LED��ʼ��
		
	RTC_Init();		      // RTC��ʼ��
	
}

/************************************************************ 
 * Function :       UsrFunction
 * Comment  :       �û�������
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/

void UsrFunction(void)
{
		
	
	while(1)
	{
			rtc_show_time();
			delay_1ms(1000);
	}
}


/****************************End*****************************/

