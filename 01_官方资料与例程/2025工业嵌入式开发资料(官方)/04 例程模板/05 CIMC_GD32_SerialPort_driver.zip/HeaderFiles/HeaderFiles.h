/************************************************************
 * ��Ȩ��2025CIMC Copyright�� 
 * �ļ���Headerfiles.h
 * ����: Lingyu Meng
 * ƽ̨: 2025 CIMC IHD V04
 * �汾: Lingyu Meng     2023/2/16     V0.01    original
************************************************************/

#ifndef __HEADERFILES_H
#define __HEADERFILES_H

/************************* ͷ�ļ� *************************/

#include "gd32f4xx.h"
#include "gd32f4xx_libopt.h"
#include "systick.h"
#include <stdio.h>
#include <stdint.h>
#include "string.h"
#include "Function.h"     // ִ�к���
#include "led.h"
#include "key.h"
#include "usart0.h"

#endif

/****************************End*****************************/

