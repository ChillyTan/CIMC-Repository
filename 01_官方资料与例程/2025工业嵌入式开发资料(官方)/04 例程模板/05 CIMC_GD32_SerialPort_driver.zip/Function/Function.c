/************************************************************
 * ��Ȩ��2025CIMC Copyright�� 
 * �ļ���Function.c
 * ����: Lingyu Meng
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Lingyu Meng     2025/2/16     V0.01    original
************************************************************/


/************************* ͷ�ļ� *************************/

#include "Function.h"

/************************* �궨�� *************************/


/************************ �������� ************************/


/************************ �������� ************************/



/************************************************************ 
 * Function :       System_Init
 * Comment  :       ���ڳ�ʼ��MCU
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/

void System_Init(void)
{
	systick_config();     // ʱ������
	
	LED_Init();
	
	USART0_Config();     // ���ڳ�ʼ��
	
	
	nvic_irq_enable(USART0_IRQn, 0, 0);//ʹ��USART0�ж�
	
	usart_interrupt_enable(USART0, USART_INT_RBNE);//�����жϴ�
	
}


/************************************************************ 
 * Function :       UsrFunction
 * Comment  :       �û�������: LED1��˸
 * Parameter:       null
 * Return   :       null
 * Author   :       Lingyu Meng
 * Date     :       2025-02-30 V0.1 original
************************************************************/

void UsrFunction(void)
{
	
	printf("CIMC Sys Init\r\n");  //���ڴ�ӡ����
	
	while(1)
	{
		LED1_OFF();
		
		delay_1ms(200);
		
		LED1_ON();
		
		delay_1ms(200);
		
	
	}
}


/****************************End*****************************/

